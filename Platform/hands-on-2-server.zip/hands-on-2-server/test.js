var qwe = "123";
var asd = "567";
if (qwe != "234"){
  console.log("good");
}
